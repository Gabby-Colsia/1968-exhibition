param([string]$SitePath = (Join-Path $PSScriptRoot 'site'))
$ErrorActionPreference = 'Stop'
$manifestPath = Join-Path $PSScriptRoot 'SHA256SUMS.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$resolvedSitePath = (Resolve-Path -LiteralPath $SitePath).Path
$issues = @()
foreach ($entry in $manifest) {
    $filePath = Join-Path $resolvedSitePath $entry.file
    if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) {
        $issues += "MISSING: $($entry.file)"
        continue
    }
    $actual = (Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $entry.sha256) { $issues += "CHANGED: $($entry.file)" }
}
if ($issues.Count -gt 0) {
    $issues | ForEach-Object { Write-Output $_ }
    throw 'Verification failed. This folder is not identical to the original published exhibition.'
}
Write-Output "PASS: All $($manifest.Count) original exhibition files match byte for byte."
Write-Output 'Additional files are allowed; this check verifies the seventeen baseline files.'
